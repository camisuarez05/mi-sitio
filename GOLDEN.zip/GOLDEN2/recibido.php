<?php
$conexion = new mysqli("localhost", "root", "", "registros");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombre = isset($_GET['Nombre']) ? $_GET['Nombre'] : 'Desconocido';
$apellido = isset($_GET['Apellido']) ? $_GET['Apellido'] : 'No especificado';
$email = isset($_GET['Email']) ? $_GET['Email'] : 'No proporcionado';
$sql = "INSERT INTO usuarios (Nombre, Apellido, Email) VALUES ('$nombre', '$apellido', '$email')";

if ($conexion->query($sql) === TRUE) {
    $mensaje = "¡Registro guardado exitosamente!";
} else {
    $mensaje = "Error al guardar los datos: " . $conexion->error;
}

$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recibido</title>
    <link rel="stylesheet" href="stylesss.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div>
        <h1>¡Gracias por Registrarte!</h1>
        <p id="mensaje"><?php echo $mensaje; ?></p>
        <p>Los datos que enviaste son:</p>
        <table>
            <tr>
                <th>Campo</th>
                <th>Valor</th>
            </tr>
            <tr>
                <td><strong>Nombre:</strong></td>
                <td><?php echo $nombre; ?></td>
            </tr>
            <tr>
                <td><strong>Apellido:</strong></td>
                <td><?php echo $apellido; ?></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><?php echo $email; ?></td>
            </tr>
        </table>
        <button id="volver">Volver al Inicio</button>
    </div>
    <script>
        $(document).ready(function() {
            if ($("#mensaje").text().includes("¡Registro guardado exitosamente!")) {
                $("#mensaje").css("color", "green");
            } else {
                $("#mensaje").css("color", "red");
            }

            $("#volver").click(function() {
                window.location.href = "index.html";
            });
        });
    </script>
</body>
</html>
