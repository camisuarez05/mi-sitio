<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="styless.css">
</head>
<body>
    <div>
        <h1>REGISTRARSE</h1>
        <form action="recibido.php" method="get">
            <label>Nombre:</label><br>
            <input type="text" name="Nombre" required><br>
            <label>Apellido:</label><br>
            <input type="text" name="Apellido" required><br>
            <label>Email:</label><br>
            <input type="email" name="Email" required><br>
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>
